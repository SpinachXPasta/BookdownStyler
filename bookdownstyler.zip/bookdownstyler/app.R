library(shiny)


runApp(launch.browser = TRUE)