observeEvent(input$user_close_editor,{
  start_edit(FALSE)
})